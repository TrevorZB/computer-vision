function [db, out_img] = compute2DProperties(orig_img, labeled_img)
