function labeled_img = generateLabeledImage(gray_img, threshold)
