function line_detected_img = lineFinder(orig_img, hough_img, hough_threshold)
