function [rgb_stack, gray_stack] = loadFocalStack(focal_stack_dir)
