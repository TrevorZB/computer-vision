function refocusApp(rgb_stack, depth_map)
