function index_map = generateIndexMap(gray_stack, w_size)
