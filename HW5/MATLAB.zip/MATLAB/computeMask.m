function mask = computeMask(img_cell)
