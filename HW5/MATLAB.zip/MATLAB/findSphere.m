function [center, radius] = findSphere(img)
