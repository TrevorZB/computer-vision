function light_dirs_5x3 = computeLightDirections(center, radius, img_cell)
