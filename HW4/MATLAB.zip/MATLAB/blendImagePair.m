function out_img = blendImagePair(wrapped_imgs, masks, wrapped_imgd, maskd, mode)
