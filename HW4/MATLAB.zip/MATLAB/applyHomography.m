function dest_pts_nx2 = applyHomography(H_3x3, src_pts_nx2)
